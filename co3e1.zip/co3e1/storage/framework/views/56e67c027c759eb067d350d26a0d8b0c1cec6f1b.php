<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Front.blade</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

</head>
<body class="#" style="border: 5px solid red" >
    <h2 class="" style="text-align: center">The Price Of Elictronic</h2>
    <div class="container">
        
            <table class="table table-borderless">

           <thead>
            <tr>
                <th scope="col">PID</th>
                <th scope="col">title</th>
                <th scope="col">Qty</th>
                <th scope="col">Price</th>
                <th scope="col">Actions</th>

              </tr>
           </thead>
        </div>
        <tbody>
            <?php $__currentLoopData = $productlist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="">

                <td scope = "row"><?php echo e($product->pid); ?></td>

                <td><?php echo e($product->title); ?></td>

                <td><?php echo e($product->qty); ?></td>

                <td><?php echo e($product->price); ?></td>

                <td>
                    <a class="btn btn-info" id="#" href="" role="button">View</a>
                    <a class="btn btn-primary" id="#" href="" role="button">Edit</a>
                    <a class="btn btn-danger" id="#" href="" role="button">Delete</a>
                    
                    
                </td>
              </tr>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    </div>

</body>
</html>
<?php /**PATH C:\xampp\laravelprojects\co3e1\resources\views/product/front.blade.php ENDPATH**/ ?>