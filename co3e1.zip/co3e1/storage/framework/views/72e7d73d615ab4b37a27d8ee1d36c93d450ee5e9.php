

<style>
    table,th,tr,td {
        border: 1px solid black;
    }
</style>
<h1>Category Show (Details)</h1>
<table>
    <tbody>
        <tr>
            <td>CID</td><td><?php echo e($item->cid); ?></td>
        </tr>
        <tr>
            <td>Title</td><td><?php echo e($item->title); ?></td>
        </tr>

    </tbody>
</table>

    <a href="<?php echo e(route("cat.index", $item->cid)); ?>">Back</a>

<?php /**PATH C:\xampp\laravelprojects\co3e1\resources\views/category_view/show.blade.php ENDPATH**/ ?>