<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Add</title>
    <style>
         table, th, tr ,td{
        border: 1px solid black;
       }
    </style>
</head>
<body>
    <h2>Create New Category</h2>
    <table>
        <tbody>
            <tr>
                <td>CID</td><td><input type="text"></td>
            </tr>
            <tr>
                <td>Title</td><td><input type="text"></td>
            </tr>
        </tbody>
    </table>
    <button type="submit">Save</button>

</body>
</html>

