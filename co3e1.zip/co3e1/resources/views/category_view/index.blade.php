<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Item</title>
    <style>

       table, th, tr ,td{
        border: 1px solid black;
       }

    </style>
</head>
<body>
    <h1>Item in category</h1>

    <h2>Create New Item</h2>
    <form action="{{route("cat.store")}}" method="post">

        @csrf
        @method('post')
        <table>
            <tbody>
                <tr>
                    <td>Title</td>
                    <td><input type="text" name="title" placeholder="Enter a title"></td>
                </tr>
            </tbody>
        </table><br>


        <button type="submit"> Save</button>


    </form><br>

    <table>
        <thead>
            <th>CID</th>
            <th>Title</th>
            <th>Actions</th>
        </thead>
        <tbody>
            @foreach ($data as $item)
                <tr>
                    <td>{{ $item->cid}}</td>
                    <td>{{ $item->title}}</td>
                    <td>
                        <form action="{{ route("cat.destroy", $item->cid) }}" method="post">

                            @csrf
                            @method("DELETE")
                            <a href="{{ route("cat.show", $item->cid) }}">View</a> |
                            <a href="{{ route("cat.edit", $item->cid) }}">Edit</a> |
                            <button type="submit">Delete</button>
                        </form>
                    </td>
                </tr>
            @endforeach
        </tbody>
    </table>

