
{{-- <h3>CID: {{ $item->cid }}</h3>
<h3>Title: {{ $item->title }} </h3>
<a href="{{ route("cat.index") }}">BACK</a> --}}
<style>
    table,th,tr,td {
        border: 1px solid black;
    }
</style>
<h1>Category Show (Details)</h1>
<table>
    <tbody>
        <tr>
            <td>CID</td><td>{{ $item->cid }}</td>
        </tr>
        <tr>
            <td>Title</td><td>{{ $item->title }}</td>
        </tr>

    </tbody>
</table>

    <a href="{{ route("cat.index", $item->cid) }}">Back</a>

