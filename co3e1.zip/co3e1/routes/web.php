<?php

use App\Http\Controllers\CategoryController;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ProductController;

Route::get('/', function () {
    return view('welcome');
});

Route::get("/product", function(){
    // return "<h1>Hello this is a product page</h1>";
    return view("my_product");
});
Route::resource('/pr', ProductController::class);
Route::resource('/cat', CategoryController::class);
