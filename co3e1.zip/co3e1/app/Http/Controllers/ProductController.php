<?php

namespace App\Http\Controllers;

use App\Models\ProductModel;
use Illuminate\Http\Request;

class ProductController extends Controller
{
    public function index()
    {
        $productlist = ProductModel ::all();
        return view("product.front", compact("productlist"));
    }

    public function create()
    {
        return view("product.add");
    }
    public function store(Request $request)
    {
        ///
    }

    public function show(string $id)
    {
        return ProductModel::find();
    }

    public function edit(){
        return view("product.change");
    }
    public function update(Request $request,string $id)
    {
        //
    }
}
