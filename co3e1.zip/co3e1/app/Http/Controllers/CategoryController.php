<?php

namespace App\Http\Controllers;

use App\Models\CategoryModel;
use Illuminate\Http\Request;

class CategoryController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $data = CategoryModel::all();

        return view("category_view.index" , compact("data")) ;
    }

    public function create()
    {

        return view("category_view.insert");
    }

    public function store(Request $request)
    {

     $this->validate($request, [
        "title" => "required"
    ]);

    CategoryModel::create($request->all());

    return redirect()->route("cat.index");


    }

    public function show(string $id)
    {
        $item = CategoryModel::find($id);

        return view("category_view.show", compact("item"));
    }


    public function edit($id)
    {
        $item = CategoryModel::find($id);
        return view("category_view.edit", compact("item"));
    }

    public function update(Request $request, $id)
    {
        //
    }
        //Use when we neet to delete (Function destroy)

    public function destroy($id)
    {
        CategoryModel::find($id)->delete();
        return redirect()->route("cat.index");

    }
}
