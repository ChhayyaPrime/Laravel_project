<?php

use Illuminate\Support\Facades\Route;

//route resource
Route::get('/', function () {
    return view('welcome');
});
Route::resource('/posts', \App\Http\Controllers\PostController::class);
